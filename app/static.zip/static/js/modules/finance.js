/**
 * finance.js — Module admin finance : onglets, dépenses, charts, export
 * VoyageIQ Pro
 */
'use strict';

/* ─────────────────────────────────────────────────────────
   État
───────────────────────────────────────────────────────── */
const charts = {};
let activeTab = 'revenus';

/* ─────────────────────────────────────────────────────────
   Init
───────────────────────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', function () {
  console.log('[VoyageIQ] Module finance chargé.');

  // KPI animés
  animateKPIs();

  // Onglets
  showTab('revenus');

  // Période revenus
  const periodeRev = document.getElementById('periode-revenus');
  if (periodeRev) {
    periodeRev.addEventListener('change', function () {
      fetchRevenus(this.value);
    });
  }

  // Fermeture backdrop
  const depenseModal = document.getElementById('depense-modal');
  if (depenseModal) {
    depenseModal.addEventListener('click', e => { if (e.target === depenseModal) closeDepenseModal(); });
  }

  // Form dépense
  const depenseForm = document.getElementById('depense-form');
  if (depenseForm) depenseForm.addEventListener('submit', handleDepenseSubmit);

  // Lignes tableau animées
  animateTableRows();

  // Charts au chargement
  if (typeof Chart !== 'undefined') {
    setTimeout(() => {
      loadRevenusChart();
      loadBudgetChart();
      loadProfitabilityChart();
    }, 100);
  }
});

/* ─────────────────────────────────────────────────────────
   Animations
───────────────────────────────────────────────────────── */
function animateKPIs() {
  document.querySelectorAll('.kpi-value[data-count]').forEach(el => {
    const io = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting) {
        animateCounter(el, parseFloat(el.dataset.count)); io.disconnect();
      }
    });
    io.observe(el);
  });
}

function animateCounter(el, target, duration = 1400) {
  const start  = performance.now();
  const isFloat = !Number.isInteger(target);
  function step(now) {
    const p = Math.min((now - start) / duration, 1);
    const ease = 1 - Math.pow(1 - p, 3);
    const v = target * ease;
    el.textContent = isFloat
      ? v.toLocaleString('fr-FR', { minimumFractionDigits: 0, maximumFractionDigits: 0 })
      : Math.round(v).toLocaleString('fr-FR');
    if (p < 1) requestAnimationFrame(step);
  }
  requestAnimationFrame(step);
}

function animateTableRows() {
  document.querySelectorAll('[id$="-table"] tbody tr').forEach((row, i) => {
    row.style.opacity   = '0';
    row.style.transform = 'translateY(10px)';
    row.style.transition = `opacity .28s ${i * 35}ms, transform .28s ${i * 35}ms`;
    requestAnimationFrame(() => { row.style.opacity = '1'; row.style.transform = ''; });
  });
}

/* ─────────────────────────────────────────────────────────
   Onglets avec animation slide
───────────────────────────────────────────────────────── */
function showTab(tabName) {
  activeTab = tabName;

  // Boutons
  document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
  const activeBtn = document.querySelector(`.tab-btn[onclick*="${tabName}"]`);
  if (activeBtn) {
    activeBtn.classList.add('active');
    // Indicateur glissant
    animateTabIndicator(activeBtn);
  }

  // Panneaux
  document.querySelectorAll('[id$="-tab"]').forEach(panel => {
    panel.classList.remove('active');
    panel.style.display = 'none';
  });

  const panel = document.getElementById(`${tabName}-tab`);
  if (panel) {
    panel.style.display = '';
    panel.style.opacity = '0';
    panel.style.transform = 'translateY(8px)';
    panel.style.transition = 'opacity .3s ease, transform .3s ease';
    requestAnimationFrame(() => {
      panel.style.opacity   = '1';
      panel.style.transform = 'translateY(0)';
      panel.classList.add('active');
    });
  }
}

function animateTabIndicator(btn) {
  let indicator = btn.parentElement.querySelector('.tab-indicator');
  if (!indicator) {
    indicator = document.createElement('span');
    indicator.className = 'tab-indicator';
    indicator.style.cssText = 'position:absolute;bottom:0;left:0;height:2px;background:var(--gold);border-radius:2px;transition:left .3s ease, width .3s ease;pointer-events:none;';
    btn.parentElement.style.position = 'relative';
    btn.parentElement.appendChild(indicator);
  }
  const rect   = btn.getBoundingClientRect();
  const parent = btn.parentElement.getBoundingClientRect();
  indicator.style.left  = (rect.left - parent.left) + 'px';
  indicator.style.width = rect.width + 'px';
}

/* ─────────────────────────────────────────────────────────
   Modal dépense
───────────────────────────────────────────────────────── */
function nouvelleDepense() {
  document.getElementById('depense-modal-title').textContent = 'Nouvelle dépense';
  document.getElementById('depense-form').reset();
  document.getElementById('depense-id').value = '';
  const dateEl = document.getElementById('date_depense');
  if (dateEl) dateEl.valueAsDate = new Date();
  openModal('depense-modal');
}

function closeDepenseModal() { closeModal('depense-modal'); }

function editDepense(depenseId) {
  fetch(`/admin/api/finance/depenses/${depenseId}`)
    .then(r => r.json())
    .then(depense => {
      document.getElementById('depense-modal-title').textContent = 'Modifier dépense';
      document.getElementById('depense-id').value    = depense.id;
      document.getElementById('date_depense').value  = depense.date ?? '';
      document.getElementById('categorie').value     = depense.categorie ?? '';
      document.getElementById('montant').value       = depense.montant ?? '';
      document.getElementById('vehicule_id').value   = depense.vehicule_id ?? '';
      document.getElementById('description').value   = depense.description ?? '';
      openModal('depense-modal');
    })
    .catch(() => showNotification('Impossible de charger la dépense.', 'error'));
}

async function handleDepenseSubmit(e) {
  e.preventDefault();
  const btn  = e.target.querySelector('[type=submit]');
  const id   = document.getElementById('depense-id')?.value;
  const data = Object.fromEntries(new FormData(e.target));
  setLoadingBtn(btn, true);
  try {
    const res = await fetch(
      id ? `/admin/api/finance/depenses/${id}` : '/admin/api/finance/depenses',
      { method: id ? 'PUT' : 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) }
    );
    if (!res.ok) throw new Error();
    showNotification(id ? 'Dépense modifiée.' : 'Dépense enregistrée.', 'success');
    closeDepenseModal();
    setTimeout(() => location.reload(), 700);
  } catch {
    showNotification('Erreur lors de l\'enregistrement.', 'error');
  } finally { setLoadingBtn(btn, false); }
}

function deleteDepense(depenseId) {
  if (!confirm('Supprimer cette dépense ?')) return;
  fetch(`/admin/api/finance/depenses/${depenseId}`, { method: 'DELETE' })
    .then(r => {
      if (!r.ok) throw new Error();
      showNotification('Dépense supprimée.', 'success');
      const row = document.querySelector(`tr[data-depense-id="${depenseId}"]`);
      if (row) slideOutRow(row);
    })
    .catch(() => showNotification('Erreur suppression.', 'error'));
}

function viewRevenueDetails(revenueId) {
  window.location.href = `/admin/finance/revenus/${revenueId}`;
}

/* ─────────────────────────────────────────────────────────
   Budget / Rapport
───────────────────────────────────────────────────────── */
function nouveauBudget() {
  showNotification('Ouverture du formulaire budget…', 'info');
}

function generateFinancialReport() {
  const btn = document.querySelector('[onclick="generateFinancialReport()"]');
  setLoadingBtn(btn, true);
  showNotification('Génération du rapport en cours…', 'info');
  setTimeout(() => {
    setLoadingBtn(btn, false);
    showNotification('Rapport financier généré.', 'success');
  }, 1800);
}

function exportFinancialData() {
  showNotification('Export des données financières…', 'info');
  window.location.href = '/admin/api/finance/export';
}

/* ─────────────────────────────────────────────────────────
   Charts Chart.js
───────────────────────────────────────────────────────── */
const chartDefaults = {
  gold: '#C9A84C',
  goldAlpha: 'rgba(201,168,76,.15)',
  ok:    'rgba(34,197,94,.7)',
  err:   'rgba(239,68,68,.7)',
  info:  'rgba(96,165,250,.7)',
  grid:  'rgba(255,255,255,.05)',
  text:  '#888',
};

function getLast6Months() {
  const months = ['Jan','Fév','Mar','Avr','Mai','Jun','Jul','Aoû','Sep','Oct','Nov','Déc'];
  const now = new Date();
  return Array.from({ length: 6 }, (_, i) => months[(now.getMonth() - 5 + i + 12) % 12]);
}

function randomData(n, min, max) {
  return Array.from({ length: n }, () => Math.floor(Math.random() * (max - min) + min));
}

function loadRevenusChart() {
  const ctx = document.getElementById('revenus-chart');
  if (!ctx) return;
  if (charts.revenus) charts.revenus.destroy();
  charts.revenus = new Chart(ctx.getContext('2d'), {
    type: 'line',
    data: {
      labels: getLast6Months(),
      datasets: [
        {
          label: 'Revenus (FCFA)',
          data: randomData(6, 800000, 2000000),
          borderColor: chartDefaults.gold,
          backgroundColor: chartDefaults.goldAlpha,
          borderWidth: 2, fill: true, tension: .4,
          pointBackgroundColor: chartDefaults.gold, pointRadius: 4
        },
        {
          label: 'Dépenses (FCFA)',
          data: randomData(6, 400000, 900000),
          borderColor: chartDefaults.err,
          backgroundColor: 'rgba(239,68,68,.08)',
          borderWidth: 2, fill: true, tension: .4,
          pointBackgroundColor: '#EF4444', pointRadius: 4
        }
      ]
    },
    options: {
      responsive: true,
      plugins: { legend: { labels: { color: chartDefaults.text, font: { size: 11 } } } },
      scales: {
        x: { grid: { color: chartDefaults.grid }, ticks: { color: chartDefaults.text } },
        y: { grid: { color: chartDefaults.grid }, ticks: { color: chartDefaults.text,
          callback: v => (v / 1000).toFixed(0) + 'k' } }
      },
      animation: { duration: 900, easing: 'easeOutQuart' }
    }
  });
}

function loadBudgetChart() {
  const ctx = document.getElementById('budget-chart');
  if (!ctx) return;
  if (charts.budget) charts.budget.destroy();
  charts.budget = new Chart(ctx.getContext('2d'), {
    type: 'doughnut',
    data: {
      labels: ['Carburant', 'Maintenance', 'Personnel', 'Autres'],
      datasets: [{
        data: [35, 25, 30, 10],
        backgroundColor: [chartDefaults.gold, chartDefaults.ok, chartDefaults.info, '#A78BFA'],
        borderWidth: 0, hoverOffset: 8
      }]
    },
    options: {
      cutout: '68%',
      plugins: {
        legend: { position: 'bottom', labels: { color: chartDefaults.text, font: { size: 11 }, padding: 14 } }
      },
      animation: { animateRotate: true, duration: 900 }
    }
  });
}

function loadProfitabilityChart() {
  const ctx = document.getElementById('profitability-chart');
  if (!ctx) return;
  if (charts.profitability) charts.profitability.destroy();
  charts.profitability = new Chart(ctx.getContext('2d'), {
    type: 'bar',
    data: {
      labels: getLast6Months(),
      datasets: [{
        label: 'Bénéfice net (FCFA)',
        data: randomData(6, 100000, 800000),
        backgroundColor: randomData(6, 1, 1).map(() => chartDefaults.goldAlpha),
        borderColor: chartDefaults.gold,
        borderWidth: 1, borderRadius: 6
      }]
    },
    options: {
      responsive: true,
      plugins: { legend: { labels: { color: chartDefaults.text } } },
      scales: {
        x: { grid: { display: false }, ticks: { color: chartDefaults.text } },
        y: { grid: { color: chartDefaults.grid }, ticks: { color: chartDefaults.text,
          callback: v => (v / 1000).toFixed(0) + 'k' } }
      },
      animation: { duration: 900 }
    }
  });
}

async function fetchRevenus(periode) {
  try {
    const res    = await fetch(`/admin/api/finance/revenus?periode=${periode}`);
    const data   = await res.json();
    updateRevenusTable(data.revenus ?? []);
    if (charts.revenus && data.chartData) {
      charts.revenus.data.labels          = data.chartData.labels;
      charts.revenus.data.datasets[0].data = data.chartData.revenus;
      charts.revenus.data.datasets[1].data = data.chartData.depenses;
      charts.revenus.update('active');
    }
  } catch {
    showNotification('Erreur chargement revenus.', 'error');
  }
}

function updateRevenusTable(revenus) {
  const tbody = document.querySelector('#revenus-table tbody');
  if (!tbody) return;
  tbody.innerHTML = revenus.length
    ? revenus.map(r => `
      <tr>
        <td>${r.date}</td>
        <td>${r.source}</td>
        <td>${(r.montant ?? 0).toLocaleString('fr-FR')} FCFA</td>
        <td><button class="action-btn" onclick="viewRevenueDetails(${r.id})" title="Détails"><i class="fas fa-eye"></i></button></td>
      </tr>`).join('')
    : `<tr><td colspan="4" style="text-align:center;color:var(--t3);padding:24px;">Aucune donnée</td></tr>`;
}

/* ─────────────────────────────────────────────────────────
   Helpers
───────────────────────────────────────────────────────── */
function openModal(id) {
  const el = document.getElementById(id);
  if (!el) return;
  el.style.display = 'flex'; el.style.opacity = '0'; el.style.transition = 'opacity .25s';
  requestAnimationFrame(() => { el.style.opacity = '1'; });
  const inner = el.querySelector('.modal-content,.modal__inner,.modal-box');
  if (inner) {
    inner.style.transform = 'scale(.96) translateY(-10px)'; inner.style.transition = 'transform .25s ease';
    requestAnimationFrame(() => { inner.style.transform = 'scale(1) translateY(0)'; });
  }
}

function closeModal(id) {
  const el = document.getElementById(id);
  if (!el) return;
  el.style.opacity = '0';
  setTimeout(() => { el.style.display = 'none'; el.style.opacity = ''; }, 230);
}

function slideOutRow(row) {
  row.style.transition = 'opacity .35s, transform .35s';
  row.style.opacity    = '0';
  row.style.transform  = 'translateX(-20px)';
  setTimeout(() => row.remove(), 380);
}

function setLoadingBtn(btn, loading) {
  if (!btn) return;
  if (loading) { btn.dataset.label = btn.innerHTML; btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>'; btn.disabled = true; }
  else { btn.innerHTML = btn.dataset.label ?? 'OK'; btn.disabled = false; }
}

function showNotification(message, type = 'info') {
  let zone = document.getElementById('notif-zone');
  if (!zone) {
    zone = document.createElement('div');
    zone.id = 'notif-zone';
    zone.style.cssText = 'position:fixed;bottom:24px;right:24px;z-index:9999;display:flex;flex-direction:column;gap:10px;';
    document.body.appendChild(zone);
  }
  const colors = { success:'#22C55E', error:'#EF4444', warning:'#F59E0B', info:'#60A5FA' };
  const icons  = { success:'check-circle', error:'exclamation-circle', warning:'exclamation-triangle', info:'info-circle' };
  const c = colors[type] ?? colors.info;
  const n = document.createElement('div');
  n.style.cssText = `display:flex;align-items:center;gap:10px;padding:12px 18px;background:var(--card);border:1px solid ${c};border-left:4px solid ${c};border-radius:8px;color:var(--t);font-size:13px;box-shadow:0 8px 24px rgba(0,0,0,.3);opacity:0;transform:translateX(20px);transition:opacity .3s,transform .3s;min-width:260px;`;
  n.innerHTML = `<i class="fas fa-${icons[type]}" style="color:${c}"></i><span>${message}</span>`;
  zone.appendChild(n);
  requestAnimationFrame(() => { n.style.opacity = '1'; n.style.transform = 'translateX(0)'; });
  setTimeout(() => { n.style.opacity = '0'; n.style.transform = 'translateX(20px)'; setTimeout(() => n.remove(), 320); }, 3600);
}
