/**
 * carte.js — Module admin carte : Leaflet, outils de dessin, itinéraires, arrêts
 * VoyageIQ Pro
 */
'use strict';

/* ─────────────────────────────────────────────────────────
   État carte
───────────────────────────────────────────────────────── */
let map           = null;
let currentTool   = 'select';
let routePoints   = [];
let routePolyline = null;
let measurePoints = [];
let measureLine   = null;
let layers        = {};
let undoStack     = [];
let redoStack     = [];

/* ─────────────────────────────────────────────────────────
   Init
───────────────────────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', function () {
  console.log('[VoyageIQ] Module carte chargé.');

  initMap();
  loadItineraires();
  loadStops();

  // Backdrop modales
  ['itineraire-modal','arret-modal','optimisation-modal'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.addEventListener('click', e => { if (e.target === el) closeModalById(id); });
  });

  // Forms
  const itinForm = document.getElementById('itineraire-form');
  if (itinForm) itinForm.addEventListener('submit', handleItineraireSubmit);

  const arretForm = document.getElementById('arret-form');
  if (arretForm) arretForm.addEventListener('submit', handleArretSubmit);

  // Recherche adresse
  const addrInput = document.getElementById('address-search');
  if (addrInput) {
    addrInput.addEventListener('keydown', e => { if (e.key === 'Enter') searchAddress(); });
  }

  // ESC
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') ['itineraire-modal','arret-modal','optimisation-modal'].forEach(closeModalById);
    if (e.key === 'z' && (e.ctrlKey || e.metaKey)) undo();
    if (e.key === 'y' && (e.ctrlKey || e.metaKey)) redo();
  });

  // Animer la sidebar
  animateSidebar();
});

/* ─────────────────────────────────────────────────────────
   Initialisation Leaflet
───────────────────────────────────────────────────────── */
function initMap() {
  const container = document.getElementById('map-container');
  if (!container) return;

  if (typeof L === 'undefined') {
    container.innerHTML = `
      <div class="map-placeholder">
        <i class="fas fa-map-marked-alt"></i>
        <span>Leaflet non chargé. Ajoutez la bibliothèque pour activer la carte.</span>
      </div>`;
    return;
  }

  map = L.map('map-container', {
    center: [3.8667, 11.5167], // Yaoundé par défaut
    zoom:   13,
    zoomControl: false
  });

  L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
    attribution: '© OpenStreetMap contributors © CARTO',
    subdomains: 'abcd', maxZoom: 19
  }).addTo(map);

  // Couches
  layers.stops      = L.layerGroup().addTo(map);
  layers.routes     = L.layerGroup().addTo(map);
  layers.drawing    = L.layerGroup().addTo(map);

  // Zoom personnalisé
  L.control.zoom({ position: 'bottomright' }).addTo(map);

  setupMapEvents();

  // Animation de chargement
  container.style.opacity   = '0';
  container.style.transition = 'opacity .6s';
  map.whenReady(() => { container.style.opacity = '1'; });
}

function setupMapEvents() {
  if (!map) return;
  map.on('click', function (e) {
    if (currentTool === 'marker') {
      addStopAtPosition(e.latlng);
    } else if (currentTool === 'route') {
      addRoutePoint(e.latlng);
    } else if (currentTool === 'measure') {
      updateMeasurement(e.latlng);
    }
  });

  map.on('mousemove', function (e) {
    if (currentTool === 'measure' && measurePoints.length > 0) {
      // Curseur mesure live (optionnel)
    }
  });
}

/* ─────────────────────────────────────────────────────────
   Chargement données
───────────────────────────────────────────────────────── */
function loadItineraires() {
  fetch('/admin/api/cartes/itineraires')
    .then(r => r.json())
    .then(data => {
      data.forEach(addItineraireToMap);
      animateItinerairesList(data);
    })
    .catch(() => { /* silencieux */ });
}

function loadStops() {
  fetch('/admin/api/cartes/arrets')
    .then(r => r.json())
    .then(data => data.forEach(addStopToMap))
    .catch(() => { /* silencieux */ });
}

function animateItinerairesList(itineraires) {
  const list = document.getElementById('itineraires-list');
  if (!list || !itineraires.length) return;
  list.querySelectorAll('.itineraire-item').forEach((item, i) => {
    item.style.opacity   = '0';
    item.style.transform = 'translateX(-10px)';
    item.style.transition = `opacity .3s ${i * 60}ms, transform .3s ${i * 60}ms`;
    requestAnimationFrame(() => { item.style.opacity = '1'; item.style.transform = ''; });
  });
}

/* ─────────────────────────────────────────────────────────
   Rendu carte
───────────────────────────────────────────────────────── */
function addItineraireToMap(itineraire) {
  if (!map || !itineraire.points) return;
  const color = itineraire.couleur ?? '#C9A84C';
  const poly  = L.polyline(itineraire.points, {
    color, weight: 4, opacity: .85, smoothFactor: 1
  });
  poly.addTo(layers.routes);
  poly.bindTooltip(itineraire.nom ?? 'Itinéraire', { sticky: true });
  poly.on('click', () => highlightItineraire(itineraire.id));
}

function addStopToMap(arret) {
  if (!map || !arret.lat || !arret.lng) return;
  const icon = L.divIcon({
    className: '',
    html: `<div style="width:12px;height:12px;border-radius:50%;background:#C9A84C;border:2px solid #fff;box-shadow:0 0 8px rgba(201,168,76,.6);"></div>`,
    iconSize: [12, 12], iconAnchor: [6, 6]
  });
  const marker = L.marker([arret.lat, arret.lng], { icon }).addTo(layers.stops);
  marker.bindPopup(createStopPopup(arret));
}

function createStopPopup(arret) {
  return `
    <div class="vehicle-popup">
      <h4><i class="fas fa-map-marker-alt"></i> ${arret.nom ?? 'Arrêt'}</h4>
      <p><i class="fas fa-info-circle"></i> ${arret.description ?? '—'}</p>
      <p style="font-size:10px;color:#666;">Lat: ${arret.lat?.toFixed(5)}, Lng: ${arret.lng?.toFixed(5)}</p>
    </div>`;
}

/* ─────────────────────────────────────────────────────────
   Outils de dessin
───────────────────────────────────────────────────────── */
function setTool(tool) {
  currentTool = tool;

  // Boutons actifs
  document.querySelectorAll('.tool-btn').forEach(btn => btn.classList.remove('active'));
  const btn = document.querySelector(`[onclick="setTool('${tool}')"]`);
  if (btn) {
    btn.classList.add('active');
    // Petit effet de rebond
    btn.style.transform = 'scale(.9)';
    setTimeout(() => { btn.style.transform = ''; btn.style.transition = 'transform .15s'; }, 120);
  }

  // Cursor carte
  if (map) {
    map.getContainer().style.cursor =
      tool === 'select' ? '' :
      tool === 'marker' ? 'crosshair' :
      tool === 'route'  ? 'cell' :
      tool === 'measure'? 'crosshair' : '';
  }

  updateToolOptions(tool);
  if (tool !== 'route') { routePoints = []; }
  if (tool !== 'measure') clearMeasurement();
}

function updateToolOptions(tool) {
  const container = document.getElementById('tool-options');
  if (!container) return;
  container.style.opacity = '0';
  container.style.transition = 'opacity .2s';

  let html = '';
  if (tool === 'route') {
    html = `
      <div style="display:flex;gap:8px;align-items:center;">
        <span style="font-size:12px;color:var(--t3)"><i class="fas fa-info-circle"></i> Cliquez sur la carte pour ajouter des points</span>
        <button class="btn btn-sm btn-success" onclick="finishRoute()"><i class="fas fa-check"></i> Terminer</button>
        <button class="btn btn-sm" onclick="routePoints=[];if(routePolyline&&map)map.removeLayer(routePolyline);">Effacer</button>
      </div>`;
  } else if (tool === 'measure') {
    html = `
      <div style="display:flex;gap:8px;align-items:center;">
        <span id="measurement-display" style="font-size:12px;color:var(--gold);font-family:var(--font-mono)">0.00 km</span>
        <button class="btn btn-sm" onclick="clearMeasurement()"><i class="fas fa-eraser"></i> Effacer</button>
      </div>`;
  } else if (tool === 'marker') {
    html = `<span style="font-size:12px;color:var(--t3)"><i class="fas fa-map-marker-alt" style="color:var(--gold)"></i> Cliquez pour placer un arrêt</span>`;
  }

  container.innerHTML = html;
  requestAnimationFrame(() => { container.style.opacity = '1'; });
}

/* ─────────────────────────────────────────────────────────
   Ajout arrêt via clic carte
───────────────────────────────────────────────────────── */
function addStopAtPosition(latlng) {
  const latEl = document.getElementById('arret-lat');
  const lngEl = document.getElementById('arret-lng');
  if (latEl) latEl.value = latlng.lat.toFixed(6);
  if (lngEl) lngEl.value = latlng.lng.toFixed(6);
  document.getElementById('arret-modal-title').textContent = 'Ajouter un arrêt';
  document.getElementById('arret-form')?.reset();
  if (latEl) latEl.value = latlng.lat.toFixed(6);
  if (lngEl) lngEl.value = latlng.lng.toFixed(6);
  openModalAnimated('arret-modal');
}

/* ─────────────────────────────────────────────────────────
   Route
───────────────────────────────────────────────────────── */
function addRoutePoint(latlng) {
  routePoints.push(latlng);

  if (routePolyline && map) map.removeLayer(routePolyline);
  if (routePoints.length >= 2) {
    routePolyline = L.polyline(routePoints, {
      color: '#C9A84C', weight: 3, opacity: .8,
      dashArray: '6 4'
    }).addTo(layers.drawing);
  }

  // Marqueur temporaire
  if (map) {
    const dot = L.circleMarker(latlng, {
      radius: 5, color: '#C9A84C', fillColor: '#C9A84C', fillOpacity: 1
    }).addTo(layers.drawing);
    undoStack.push({ type: 'point', marker: dot });
  }

  updateInfoPanel(
    calculateDistance(routePoints),
    routePoints.length * 2,
    routePoints.length
  );
}

function finishRoute() {
  if (routePoints.length < 2) {
    showNotification('Tracez au moins 2 points.', 'warning'); return;
  }
  calculateRoute(routePoints);
  routePoints = [];
}

function calculateRoute(points) {
  const distance = calculateDistance(points);
  const duration = distance * 2.5; // estimation grossière
  updateInfoPanel(distance, duration, points.length);
  showNotification(`Route tracée : ${distance.toFixed(1)} km, ~${Math.round(duration)} min.`, 'success');
}

function calculateDistance(points) {
  if (!map || points.length < 2) return 0;
  let d = 0;
  for (let i = 1; i < points.length; i++) {
    d += points[i - 1].distanceTo(points[i]);
  }
  return d / 1000; // km
}

function updateInfoPanel(distance, duration, stops) {
  const panel = document.getElementById('info-panel');
  if (panel) {
    panel.style.opacity = '0'; panel.style.transition = 'opacity .3s';
    setTimeout(() => { panel.style.opacity = '1'; }, 50);
  }
  const distEl = document.getElementById('info-distance');
  const durEl  = document.getElementById('info-duration');
  const stpEl  = document.getElementById('info-stops');
  if (distEl) distEl.textContent = `Distance : ${distance.toFixed(1)} km`;
  if (durEl)  durEl.textContent  = `Durée estimée : ${Math.round(duration)} min`;
  if (stpEl)  stpEl.textContent  = `Points : ${stops}`;
}

/* ─────────────────────────────────────────────────────────
   Mesure
───────────────────────────────────────────────────────── */
function updateMeasurement(latlng) {
  measurePoints.push(latlng);
  if (measureLine && map) map.removeLayer(measureLine);
  if (measurePoints.length >= 2) {
    measureLine = L.polyline(measurePoints, {
      color: '#60A5FA', weight: 2, dashArray: '4 4'
    }).addTo(layers.drawing);
    const dist = calculateDistance(measurePoints);
    const display = document.getElementById('measurement-display');
    if (display) {
      display.textContent = `${dist.toFixed(3)} km`;
      display.style.transform = 'scale(1.1)';
      display.style.transition = 'transform .15s';
      setTimeout(() => { display.style.transform = ''; }, 200);
    }
  }
}

function clearMeasurement() {
  measurePoints = [];
  if (measureLine && map) { map.removeLayer(measureLine); measureLine = null; }
  const display = document.getElementById('measurement-display');
  if (display) display.textContent = '0.000 km';
}

/* ─────────────────────────────────────────────────────────
   Couches
───────────────────────────────────────────────────────── */
function toggleLayer(layerName) {
  if (!map || !layers[layerName]) return;
  const item  = document.querySelector(`[data-layer="${layerName}"]`);
  const check = item?.querySelector('input[type=checkbox]');

  if (map.hasLayer(layers[layerName])) {
    map.removeLayer(layers[layerName]);
    if (check) check.checked = false;
  } else {
    map.addLayer(layers[layerName]);
    if (check) check.checked = true;
  }
}

/* ─────────────────────────────────────────────────────────
   Contrôles carte
───────────────────────────────────────────────────────── */
function zoomIn()  { if (map) map.zoomIn(); }
function zoomOut() { if (map) map.zoomOut(); }

function fitBounds() {
  if (!map) return;
  const group = L.featureGroup([layers.stops, layers.routes]);
  if (group.getBounds().isValid()) map.fitBounds(group.getBounds(), { padding: [30, 30] });
}

function toggleFullscreen() {
  const container = document.getElementById('map-container')?.closest('.carte-map');
  if (!container) return;
  if (!document.fullscreenElement) {
    container.requestFullscreen?.();
  } else {
    document.exitFullscreen?.();
  }
}

/* ─────────────────────────────────────────────────────────
   Undo / Redo
───────────────────────────────────────────────────────── */
function undo() {
  const action = undoStack.pop();
  if (!action) return;
  redoStack.push(action);
  if (action.type === 'point' && map) map.removeLayer(action.marker);
  if (action.type === 'stop'  && map) { map.removeLayer(action.marker); layers.stops.removeLayer(action.marker); }
  showNotification('Action annulée.', 'info');
}

function redo() {
  const action = redoStack.pop();
  if (!action) return;
  undoStack.push(action);
  if (action.marker && map) action.marker.addTo(layers.drawing);
  showNotification('Action rétablie.', 'info');
}

function clearSelection() {
  layers.drawing.clearLayers();
  routePoints   = [];
  measurePoints = [];
  routePolyline = null;
  measureLine   = null;
  undoStack     = [];
  redoStack     = [];
  showNotification('Sélection effacée.', 'info');
}

async function saveChanges() {
  showNotification('Sauvegarde…', 'info');
  try {
    const res = await fetch('/admin/api/cartes/save', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ timestamp: new Date().toISOString() })
    });
    if (!res.ok) throw new Error();
    showNotification('Modifications sauvegardées.', 'success');
  } catch {
    showNotification('Erreur lors de la sauvegarde.', 'error');
  }
}

/* ─────────────────────────────────────────────────────────
   Recherche adresse
───────────────────────────────────────────────────────── */
async function searchAddress() {
  const q       = document.getElementById('address-search')?.value;
  const results = document.getElementById('search-results');
  if (!q || !results) return;

  results.innerHTML = `<div style="padding:8px;font-size:12px;color:var(--t3)"><i class="fas fa-spinner fa-spin"></i> Recherche…</div>`;
  results.style.display = 'block';

  try {
    const res  = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(q)}&limit=5`);
    const data = await res.json();

    if (!data.length) {
      results.innerHTML = `<div style="padding:8px;font-size:12px;color:var(--t3)">Aucun résultat.</div>`;
      return;
    }

    results.innerHTML = data.map(r => `
      <div class="search-result-item" onclick="goToAddress(${r.lat}, ${r.lon}, '${r.display_name.replace(/'/g,"\\'")}')">
        <i class="fas fa-map-marker-alt" style="color:var(--gold)"></i>
        <span>${r.display_name}</span>
      </div>`).join('');

    results.querySelectorAll('.search-result-item').forEach(item => {
      item.style.cssText += 'display:flex;gap:8px;align-items:flex-start;padding:8px 12px;cursor:pointer;font-size:12px;color:var(--t2);transition:background .15s;';
      item.addEventListener('mouseenter', () => item.style.background = 'var(--bg3)');
      item.addEventListener('mouseleave', () => item.style.background = '');
    });
  } catch {
    results.innerHTML = `<div style="padding:8px;font-size:12px;color:var(--err)">Erreur de recherche.</div>`;
  }
}

function goToAddress(lat, lng, name) {
  if (map) {
    map.flyTo([lat, lng], 16, { duration: 1 });
    L.popup().setLatLng([lat, lng]).setContent(`<b>${name}</b>`).openOn(map);
  }
  const results = document.getElementById('search-results');
  if (results) results.style.display = 'none';
}

/* ─────────────────────────────────────────────────────────
   Gestion itinéraires
───────────────────────────────────────────────────────── */
function nouvelItineraire() {
  document.getElementById('itineraire-form')?.reset();
  document.getElementById('itineraire-id').value = '';
  document.getElementById('modal-title').textContent = 'Nouvel itinéraire';
  openModalAnimated('itineraire-modal');
}

function closeItineraireModal() { closeModalById('itineraire-modal'); }

function editerItineraire(id) {
  fetch(`/admin/api/cartes/itineraires/${id}`)
    .then(r => r.json())
    .then(data => {
      document.getElementById('modal-title').textContent = 'Modifier itinéraire';
      const fields = { 'itineraire-id':'id','nom_itineraire':'nom','ligne_id':'ligne_id',
                       'couleur_itineraire':'couleur','description_itineraire':'description','frequence':'frequence' };
      Object.entries(fields).forEach(([fid, key]) => {
        const el = document.getElementById(fid);
        if (el) el.value = data[key] ?? '';
      });
      openModalAnimated('itineraire-modal');
    })
    .catch(() => showNotification('Erreur chargement itinéraire.', 'error'));
}

function dupliquerItineraire(id) {
  fetch(`/admin/api/cartes/itineraires/${id}/duplicate`, { method: 'POST' })
    .then(r => { if (!r.ok) throw new Error(); return r.json(); })
    .then(() => { showNotification('Itinéraire dupliqué.', 'success'); setTimeout(() => location.reload(), 700); })
    .catch(() => showNotification('Erreur duplication.', 'error'));
}

function supprimerItineraire(id) {
  if (!confirm('Supprimer cet itinéraire ?')) return;
  fetch(`/admin/api/cartes/itineraires/${id}`, { method: 'DELETE' })
    .then(r => { if (!r.ok) throw new Error(); return r.json(); })
    .then(() => {
      showNotification('Itinéraire supprimé.', 'success');
      const item = document.querySelector(`[data-itineraire-id="${id}"]`);
      if (item) { item.style.transition = 'opacity .3s'; item.style.opacity = '0'; setTimeout(() => item.remove(), 330); }
    })
    .catch(() => showNotification('Erreur suppression.', 'error'));
}

async function handleItineraireSubmit(e) {
  e.preventDefault();
  const btn  = e.target.querySelector('[type=submit]');
  const id   = document.getElementById('itineraire-id')?.value;
  const data = Object.fromEntries(new FormData(e.target));
  setLoadingBtn(btn, true);
  try {
    const res = await fetch(
      id ? `/admin/api/cartes/itineraires/${id}` : '/admin/api/cartes/itineraires',
      { method: id ? 'PUT' : 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) }
    );
    if (!res.ok) throw new Error();
    showNotification(id ? 'Itinéraire modifié.' : 'Itinéraire créé.', 'success');
    closeItineraireModal();
    loadItineraires();
  } catch {
    showNotification('Erreur enregistrement.', 'error');
  } finally { setLoadingBtn(btn, false); }
}

/* ─────────────────────────────────────────────────────────
   Gestion arrêts
───────────────────────────────────────────────────────── */
function closeArretModal() { closeModalById('arret-modal'); }

async function handleArretSubmit(e) {
  e.preventDefault();
  const btn  = e.target.querySelector('[type=submit]');
  const id   = document.getElementById('arret-id')?.value;
  const data = Object.fromEntries(new FormData(e.target));
  setLoadingBtn(btn, true);
  try {
    const res = await fetch(
      id ? `/admin/api/cartes/arrets/${id}` : '/admin/api/cartes/arrets',
      { method: id ? 'PUT' : 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) }
    );
    if (!res.ok) throw new Error();
    showNotification(id ? 'Arrêt modifié.' : 'Arrêt créé.', 'success');
    const latlng = { lat: parseFloat(data.arret_lat ?? data.lat), lng: parseFloat(data.arret_lng ?? data.lng) };
    addStopToMap({ ...data, lat: latlng.lat, lng: latlng.lng });
    closeArretModal();
  } catch {
    showNotification('Erreur enregistrement arrêt.', 'error');
  } finally { setLoadingBtn(btn, false); }
}

/* ─────────────────────────────────────────────────────────
   Optimisation
───────────────────────────────────────────────────────── */
function optimiserRoutes() {
  openModalAnimated('optimisation-modal');
}

function closeOptimisationModal() { closeModalById('optimisation-modal'); }

function appliquerOptimisation() {
  const resultsEl = document.getElementById('optimisation-results');
  if (resultsEl) {
    resultsEl.innerHTML = `<div style="text-align:center;padding:20px"><i class="fas fa-spinner fa-spin" style="color:var(--gold);font-size:24px;"></i><p style="color:var(--t3);margin-top:12px;">Calcul en cours…</p></div>`;
  }
  setTimeout(() => {
    if (resultsEl) {
      resultsEl.innerHTML = `
        <div style="padding:16px;background:rgba(34,197,94,.06);border:1px solid var(--ok);border-radius:8px;">
          <p style="color:var(--ok);font-weight:600;"><i class="fas fa-check-circle"></i> Optimisation calculée</p>
          <p style="font-size:12px;color:var(--t2);margin-top:6px;">Réduction estimée du temps de trajet : <strong style="color:var(--gold)">12%</strong></p>
        </div>`;
    }
    showNotification('Optimisation des routes calculée.', 'success');
  }, 1600);
}

/* ─────────────────────────────────────────────────────────
   Import / Export
───────────────────────────────────────────────────────── */
function importerCarte() {
  showNotification('Importer un fichier GeoJSON ou KML.', 'info');
}

function exporterCarte() {
  showNotification('Export GeoJSON de la carte en cours…', 'info');
  window.location.href = '/admin/api/cartes/export';
}

/* ─────────────────────────────────────────────────────────
   Highlight itinéraire sélectionné
───────────────────────────────────────────────────────── */
function highlightItineraire(id) {
  document.querySelectorAll('.itineraire-item').forEach(item => {
    item.classList.toggle('active', item.dataset.itineraireId == id);
  });
}

/* ─────────────────────────────────────────────────────────
   Sidebar animation
───────────────────────────────────────────────────────── */
function animateSidebar() {
  const sidebar = document.querySelector('.carte-sidebar');
  if (!sidebar) return;
  sidebar.style.opacity   = '0';
  sidebar.style.transform = 'translateX(-10px)';
  sidebar.style.transition = 'opacity .4s .2s, transform .4s .2s';
  requestAnimationFrame(() => { sidebar.style.opacity = '1'; sidebar.style.transform = ''; });
}

/* ─────────────────────────────────────────────────────────
   Helpers
───────────────────────────────────────────────────────── */
function openModalAnimated(id) {
  const el = document.getElementById(id);
  if (!el) return;
  el.style.display = 'flex'; el.style.opacity = '0'; el.style.transition = 'opacity .25s';
  requestAnimationFrame(() => { el.style.opacity = '1'; });
  const inner = el.querySelector('.modal-content,.modal__inner,.modal-box');
  if (inner) {
    inner.style.transform = 'scale(.96) translateY(-10px)'; inner.style.transition = 'transform .25s';
    requestAnimationFrame(() => { inner.style.transform = ''; });
  }
}

function closeModalById(id) {
  const el = document.getElementById(id);
  if (!el) return;
  el.style.opacity = '0';
  setTimeout(() => { el.style.display = 'none'; el.style.opacity = ''; }, 230);
}

function setLoadingBtn(btn, loading) {
  if (!btn) return;
  if (loading) { btn.dataset.label = btn.innerHTML; btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>'; btn.disabled = true; }
  else { btn.innerHTML = btn.dataset.label ?? 'OK'; btn.disabled = false; }
}

function showNotification(message, type = 'info') {
  let zone = document.getElementById('notif-zone');
  if (!zone) {
    zone = document.createElement('div'); zone.id = 'notif-zone';
    zone.style.cssText = 'position:fixed;bottom:24px;right:24px;z-index:9999;display:flex;flex-direction:column;gap:10px;';
    document.body.appendChild(zone);
  }
  const colors = { success:'#22C55E', error:'#EF4444', warning:'#F59E0B', info:'#60A5FA' };
  const icons  = { success:'check-circle', error:'exclamation-circle', warning:'exclamation-triangle', info:'info-circle' };
  const c = colors[type] ?? colors.info;
  const n = document.createElement('div');
  n.style.cssText = `display:flex;align-items:center;gap:10px;padding:12px 18px;background:var(--card);border:1px solid ${c};border-left:4px solid ${c};border-radius:8px;color:var(--t);font-size:13px;box-shadow:0 8px 24px rgba(0,0,0,.3);opacity:0;transform:translateX(20px);transition:opacity .3s,transform .3s;min-width:260px;max-width:360px;`;
  n.innerHTML = `<i class="fas fa-${icons[type]}" style="color:${c};flex-shrink:0;"></i><span>${message}</span>`;
  zone.appendChild(n);
  requestAnimationFrame(() => { n.style.opacity = '1'; n.style.transform = 'translateX(0)'; });
  setTimeout(() => { n.style.opacity = '0'; n.style.transform = 'translateX(20px)'; setTimeout(() => n.remove(), 320); }, 3800);
}
