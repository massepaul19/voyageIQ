from flask import Blueprint, render_template, request, jsonify, flash
from flask_login import login_required, current_user
from app.models.saisie import Saisie
from app.models.ligne import Ligne

bp_rapports = Blueprint('rapports', __name__)


@bp_rapports.route('/')
@login_required
def index():
    page          = request.args.get('page', 1, type=int)
    lignes        = Ligne.query.filter_by(actif=True).all()
    pagination    = Saisie.query.order_by(Saisie.date.desc()).paginate(page=page, per_page=10)

    # Simulation des attributs attendus par le template admin_rapports.html
    for s in pagination.items:
        s.date_debut = s.date
        s.date_fin = s.date

    return render_template('admin/admin_rapports.html', lignes=lignes, rapports=pagination)


@bp_rapports.route('/generer', methods=['POST'])
@login_required
def generer():
    """Génère les données d'un rapport (JSON pour PDF côté client)."""
    try:
        type_rapport = request.form.get('type', 'exploitation')
        periode      = request.form.get('periode', '30')
        ligne_id     = request.form.get('ligne_id')

        from datetime import date, timedelta
        date_fin   = date.today()
        date_debut = date_fin - timedelta(days=int(periode))

        query = Saisie.query.filter(
            Saisie.date >= date_debut,
            Saisie.date <= date_fin
        )
        if ligne_id and ligne_id != 'toutes':
            query = query.filter_by(ligne_id=int(ligne_id))

        saisies = query.order_by(Saisie.date.asc()).all()

        data = [{
            'date'      : str(s.date),
            'ligne'     : s.ligne.nom if s.ligne else '—',
            'voyages'   : s.voyages,
            'passagers' : s.passagers,
            'recettes'  : s.recettes_total(),
            'depenses'  : s.depenses_total(),
            'marge'     : s.marge(),
            'taux_rem'  : s.taux_remplissage(),
        } for s in saisies]

        # Calcul des totaux pour le résumé du rapport
        resume = {
            'total_voyages': sum(d['voyages'] for d in data),
            'total_passagers': sum(d['passagers'] for d in data),
            'total_recettes': sum(d['recettes'] for d in data),
            'total_depenses': sum(d['depenses'] for d in data),
            'genere_par': current_user.nom_complet() if hasattr(current_user, 'nom_complet') else "Admin",
            'date_generation': str(date.today())
        }

        return jsonify({'status': 'success', 'rapport': type_rapport, 'periode': periode, 'data': data, 'resume': resume})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 400