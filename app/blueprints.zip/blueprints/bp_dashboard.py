# ═══════════════════════════════════════════════════════════════
# bp_dashboard.py
# ═══════════════════════════════════════════════════════════════
from flask import Blueprint, render_template
from flask_login import login_required, current_user
from app.models.alerte import Alerte
from app.models.utilisateur import Utilisateur
from app.models.vehicule import Vehicule
from app.models.ligne import Ligne
from app.models.saisie import Saisie
from app.extensions import db

bp_dashboard = Blueprint('dashboard', __name__)


@bp_dashboard.route('/')
@login_required
def index():
    # Si c'est un chauffeur connecté ici par erreur → renvoyer chez lui
    if hasattr(current_user, 'statut_inscription'):
        from flask import redirect, url_for
        return redirect(url_for('chauffeur.index'))

    from datetime import date
    today = date.today()

    # Somme globale de toutes les sources de recettes (Guichet + Réservation + Digital)
    recettes_total = db.session.query(
        db.func.sum(Saisie.rec_guichet + Saisie.rec_reservation + Saisie.rec_digital)
    ).scalar() or 0

    stats = {
        'total_vehicules' : Vehicule.query.count(),
        'vehicules_ok'    : Vehicule.query.filter_by(statut='operationnel').count(),
        'total_lignes'    : Ligne.query.filter_by(actif=True).count(),
        'total_users'     : Utilisateur.query.filter_by(actif=True).count(),
        'saisies_today'   : Saisie.query.filter_by(date=today).count(),
        'recettes_total'  : recettes_total,
    }

    alertes_recentes = Alerte.query\
        .filter_by(lue=False)\
        .order_by(Alerte.created_at.desc())\
        .limit(5).all()

    saisies_recentes = Saisie.query\
        .order_by(Saisie.date.desc())\
        .limit(10).all()

    # Préparation de l'objet kpi attendu par le template dashboard
    kpi = {
        'utilisateurs_actifs': stats['total_users'],
        'vehicules_en_route': stats['vehicules_ok'],
    }

    return render_template('admin/admin_dashboard.html',
                           stats=stats, kpi=kpi,
                           alertes_recentes=alertes_recentes,
                           saisies_recentes=saisies_recentes)
