from flask import Blueprint, jsonify, request
from flask_login import login_required
from app.models.saisie import Saisie
from app.models.vehicule import Vehicule
from app.models.ligne import Ligne
from app.models.alerte import Alerte
from app.extensions import db

bp_api = Blueprint('api', __name__)


@bp_api.route('/kpis')
@login_required
def kpis():
    try:
        from app.services.kpi_service import kpis_globaux
        return jsonify(kpis_globaux(30))
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@bp_api.route('/saisies')
@login_required
def saisies():
    s = Saisie.query.order_by(Saisie.date.desc()).limit(50).all()
    return jsonify([{
        'date'     : str(r.date),
        'recettes' : r.recettes_total(),
        'depenses' : r.depenses_total(),
        'marge'    : r.marge(),
        'voyages'  : r.voyages,
        'passagers': r.passagers,
        'taux_rem' : r.taux_remplissage(),
    } for r in s])


@bp_api.route('/alertes')
@login_required
def alertes():
    a = Alerte.query.filter_by(lue=False)\
               .order_by(Alerte.created_at.desc()).limit(10).all()
    return jsonify([{
        'id'     : al.id,
        'titre'  : al.titre,
        'niveau' : al.niveau,
        'type'   : al.type_alerte,
    } for al in a])


@bp_api.route('/flotte')
@login_required
def flotte():
    vehicules = Vehicule.query.all()
    return jsonify([{
        'id'    : v.id,
        'plaque': v.plaque,
        'statut': v.statut,
        'km'    : v.km_actuel,
        'ligne' : v.ligne.nom if v.ligne else None,
    } for v in vehicules])


@bp_api.route('/position', methods=['POST'])
@login_required
def position():
    """Reçoit la position GPS d'un chauffeur (pour la carte)."""
    data = request.get_json(silent=True) or {}
    lat  = data.get('lat')
    lng  = data.get('lng')
    if lat and lng:
        # TODO : stocker dans un modèle Position ou en cache Redis
        return jsonify({'status': 'ok', 'lat': lat, 'lng': lng})
    return jsonify({'status': 'error', 'message': 'lat/lng requis'}), 400


# ═══════════════════════════════════════════════════════════════
# Helper partagé — compte des alertes non lues
# (utilisé dans tous les blueprints pour la topbar)
# ═══════════════════════════════════════════════════════════════
def _alertes_count():
    try:
        from app.models.alerte import Alerte
        return Alerte.query.filter_by(lue=False).count()
    except Exception:
        return 0