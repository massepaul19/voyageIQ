from flask import Blueprint, render_template
from flask_login import login_required
from app.models.saisie import Saisie
from app.models.ligne import Ligne
from app.utils.decorators import role_required

bp_analytique = Blueprint('analytique', __name__)


@bp_analytique.route('/')
@login_required
@role_required('admin', 'dg', 'auditeur')
def index():
    from app.services.kpi_service import kpis_globaux
    kpis          = kpis_globaux(90)
    
    # Initialisation de l'objet analytics avec toutes les clés attendues par le template
    analytics = {
        'passagers_total': kpis.get('passagers_total', 0),
        'marge_moyenne': kpis.get('marge_exploitation', 0),
        'taux_ponctualite': kpis.get('taux_ponctualite', 0),
        'note_moyenne': kpis.get('note_moyenne', 0),
        'taux_occupation': kpis.get('taux_occupation', 0),
        'evolution_attente': kpis.get('evolution_attente', 0.0),
        'distance_moyenne': kpis.get('distance_moyenne', 0.0),
        'consommation_moyenne': kpis.get('conso_100km', 0),
        'evolution_consommation': kpis.get('evolution_consommation', 0.0),
        'evolution_passagers': kpis.get('evolution_passagers', 0.0),
        'km_parcourus': kpis.get('km_total', 0),
        'evolution_km': kpis.get('evolution_km', 0.0),
        'temps_attente_moyen': kpis.get('temps_attente_moyen', 0),
        'heure_pic': 17,
        'jour_charge': "Vendredi",
        'taux_fidelite': 0.0,
        'satisfaction_moyenne': kpis.get('nps_moyen', 0.0) / 20 if kpis.get('nps_moyen') else 0.0,
        'top_lignes': [],
        'lignes_analysis': [],
        'predictions': {
            'alerts': [], 'recommendations': [], 'demande_trend': 0, 'revenus_prevus': 0,
            'demand_forecast': {'labels': [], 'data': []},
            'revenue_forecast': {'labels': [], 'data': []}
        },
        'performance_chart': {'labels': [], 'courses': []},
        'revenus_chart': {'labels': [], 'data': []},
        'distance_chart': {'labels': [], 'data': []},
        'flux_horaires': {'labels': [], 'data': []},
        'age_distribution': {'labels': [], 'data': []},
        'lignes_comparison': {'labels': [], 'datasets': []}
    }

    saisies       = Saisie.query.order_by(Saisie.date.asc()).all()
    lignes        = Ligne.query.filter_by(actif=True).all()
    return render_template('admin/admin_analytique.html',
                           analytics=analytics, kpis=kpis, saisies=saisies, lignes=lignes)