/**
 * dashboard.js — Logique spécifique au tableau de bord
 * Graphiques Chart.js, rafraîchissement KPI, etc.
 */
document.addEventListener('DOMContentLoaded', function () {
  console.log('[VoyageIQ] Dashboard chargé.');

  // ── Initialisation Chart.js ─────────────────────────────
  let charts = {};

  // Vérifier si Chart.js est disponible
  if (typeof Chart !== 'undefined') {
    initCharts();
  } else {
    console.warn('[VoyageIQ] Chart.js non chargé, graphiques désactivés');
  }

  function initCharts() {
    // Graphique des recettes
    const recettesCtx = document.getElementById('recettesChart');
    if (recettesCtx) {
      charts.recettes = new Chart(recettesCtx, {
        type: 'line',
        data: {
          labels: getLast7Days(),
          datasets: [{
            label: 'Recettes (FCFA)',
            data: generateRandomData(7, 50000, 150000),
            borderColor: 'var(--gold)',
            backgroundColor: 'rgba(201,168,76,.1)',
            tension: 0.4,
            fill: true
          }]
        },
        options: getChartOptions('Recettes des 7 derniers jours')
      });
    }

    // Graphique des voyages
    const voyagesCtx = document.getElementById('voyagesChart');
    if (voyagesCtx) {
      charts.voyages = new Chart(voyagesCtx, {
        type: 'bar',
        data: {
          labels: getLast7Days(),
          datasets: [{
            label: 'Nombre de voyages',
            data: generateRandomData(7, 10, 50),
            backgroundColor: 'var(--marine)',
            borderColor: 'var(--marine-light)',
            borderWidth: 1
          }]
        },
        options: getChartOptions('Voyages effectués')
      });
    }

    // Graphique donut pour répartition
    const repartitionCtx = document.getElementById('repartitionChart');
    if (repartitionCtx) {
      charts.repartition = new Chart(repartitionCtx, {
        type: 'doughnut',
        data: {
          labels: ['Guichet', 'Réservation', 'Digital'],
          datasets: [{
            data: [45, 30, 25],
            backgroundColor: [
              'var(--gold)',
              'var(--marine)',
              'var(--orange)'
            ],
            borderWidth: 0
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              position: 'bottom',
              labels: {
                color: 'var(--t)',
                font: {
                  size: 12,
                  family: 'var(--font-main)'
                }
              }
            }
          }
        }
      });
    }
  }

  function getChartOptions(title) {
    return {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          display: false
        },
        title: {
          display: true,
          text: title,
          color: 'var(--t)',
          font: {
            size: 14,
            weight: '600',
            family: 'var(--font-main)'
          }
        }
      },
      scales: {
        x: {
          grid: {
            color: 'var(--border)'
          },
          ticks: {
            color: 'var(--t3)',
            font: {
              size: 11
            }
          }
        },
        y: {
          grid: {
            color: 'var(--border)'
          },
          ticks: {
            color: 'var(--t3)',
            font: {
              size: 11
            }
          }
        }
      },
      interaction: {
        intersect: false,
        mode: 'index'
      }
    };
  }

  function getLast7Days() {
    const days = [];
    const today = new Date();

    for (let i = 6; i >= 0; i--) {
      const date = new Date(today);
      date.setDate(today.getDate() - i);
      days.push(date.toLocaleDateString('fr-FR', {
        weekday: 'short',
        day: 'numeric'
      }));
    }

    return days;
  }

  function generateRandomData(count, min, max) {
    const data = [];
    for (let i = 0; i < count; i++) {
      data.push(Math.floor(Math.random() * (max - min + 1)) + min);
    }
    return data;
  }

  // ── Mise à jour temps réel des KPIs ────────────────────
  function updateKPIs() {
    // Simulation de mise à jour temps réel
    const kpiElements = document.querySelectorAll('[data-kpi]');

    kpiElements.forEach(element => {
      const kpiType = element.getAttribute('data-kpi');
      const currentValue = parseFloat(element.textContent.replace(/[^\d.-]/g, ''));

      // Petite variation aléatoire
      const variation = (Math.random() - 0.5) * 0.02; // ±1%
      const newValue = currentValue * (1 + variation);

      // Animation de mise à jour
      animateNumber(element, currentValue, newValue, 1000);
    });
  }

  function animateNumber(element, start, end, duration) {
    const startTime = performance.now();
    const isMoney = element.textContent.includes('FCFA');

    function update(currentTime) {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);

      const current = start + (end - start) * progress;

      if (isMoney) {
        element.textContent = current.toLocaleString('fr-FR', {
          style: 'currency',
          currency: 'XAF',
          minimumFractionDigits: 0
        });
      } else {
        element.textContent = Math.round(current).toLocaleString('fr-FR');
      }

      if (progress < 1) {
        requestAnimationFrame(update);
      }
    }

    requestAnimationFrame(update);
  }

  // ── Rafraîchissement automatique ────────────────────────
  let refreshInterval;

  function startAutoRefresh() {
    refreshInterval = setInterval(() => {
      updateKPIs();

      // Mise à jour des graphiques
      if (charts.recettes) {
        const newData = generateRandomData(7, 50000, 150000);
        charts.recettes.data.datasets[0].data = newData;
        charts.recettes.update('none');
      }

      if (charts.voyages) {
        const newData = generateRandomData(7, 10, 50);
        charts.voyages.data.datasets[0].data = newData;
        charts.voyages.update('none');
      }

    }, 30000); // Toutes les 30 secondes
  }

  function stopAutoRefresh() {
    if (refreshInterval) {
      clearInterval(refreshInterval);
    }
  }

  // ── Contrôles du dashboard ─────────────────────────────
  const refreshBtn = document.getElementById('refreshDashboard');
  if (refreshBtn) {
    refreshBtn.addEventListener('click', function() {
      updateKPIs();
      Object.values(charts).forEach(chart => chart.update());

      // Animation du bouton
      this.innerHTML = '✓ Actualisé';
      this.disabled = true;

      setTimeout(() => {
        this.innerHTML = '🔄 Actualiser';
        this.disabled = false;
      }, 2000);
    });
  }

  // ── Thème sombre/clair ────────────────────────────────
  const themeToggle = document.getElementById('themeToggle');
  if (themeToggle) {
    themeToggle.addEventListener('click', function() {
      document.documentElement.classList.toggle('light-theme');

      const isLight = document.documentElement.classList.contains('light-theme');
      localStorage.setItem('theme', isLight ? 'light' : 'dark');

      this.innerHTML = isLight ? '🌙' : '☀️';
    });

    // Restaurer le thème sauvegardé
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'light') {
      document.documentElement.classList.add('light-theme');
      themeToggle.innerHTML = '🌙';
    }
  }

  // ── Export des graphiques ─────────────────────────────
  const exportButtons = document.querySelectorAll('[data-export-chart]');
  exportButtons.forEach(btn => {
    btn.addEventListener('click', function() {
      const chartId = this.getAttribute('data-export-chart');
      const chart = charts[chartId];

      if (chart) {
        const link = document.createElement('a');
        link.download = `${chartId}.png`;
        link.href = chart.toBase64Image();
        link.click();
      }
    });
  });

  // ── Démarrage ──────────────────────────────────────────
  startAutoRefresh();

  // Cleanup on page unload
  window.addEventListener('beforeunload', stopAutoRefresh);
});
