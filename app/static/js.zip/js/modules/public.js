'use strict';
/* ═══════════════════════════════════════════════════════════════
   VoyageIQ-Pro — public.js
   Interactions et animations de la vitrine publique
   ═══════════════════════════════════════════════════════════════ */

document.addEventListener('DOMContentLoaded', () => {

  /* ── Compteur animé (stats hero) ──────────────────────────── */
  function animateCounter(el) {
    const target   = parseInt(el.dataset.count, 10) || 0;
    const duration = 1800;
    const start    = performance.now();

    function update(now) {
      const elapsed  = now - start;
      const progress = Math.min(elapsed / duration, 1);
      // Ease out cubic
      const ease     = 1 - Math.pow(1 - progress, 3);
      el.textContent = Math.round(ease * target);
      if (progress < 1) requestAnimationFrame(update);
    }
    requestAnimationFrame(update);
  }

  // Observer intersection pour déclencher les compteurs
  const counterObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting && !entry.target.dataset.counted) {
        entry.target.dataset.counted = 'true';
        animateCounter(entry.target);
      }
    });
  }, { threshold: 0.5 });

  document.querySelectorAll('[data-count]').forEach(el => {
    counterObserver.observe(el);
  });

  /* ── Animations d'entrée au scroll ────────────────────────── */
  const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        revealObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });

  document.querySelectorAll('.ligne-card, .service-card, .contact-card, .agence-card').forEach((el, i) => {
    el.style.opacity      = '0';
    el.style.transform    = 'translateY(24px)';
    el.style.transition   = `opacity 0.5s ease ${i * 0.07}s, transform 0.5s ease ${i * 0.07}s`;
    revealObserver.observe(el);
  });

  // Ajouter la classe is-visible
  document.head.insertAdjacentHTML('beforeend', `
    <style>.is-visible { opacity: 1 !important; transform: none !important; }</style>
  `);

  /* ── Smooth scroll pour les ancres ────────────────────────── */
  document.querySelectorAll('a[href^="#"]').forEach(link => {
    link.addEventListener('click', e => {
      const target = document.querySelector(link.getAttribute('href'));
      if (!target) return;
      e.preventDefault();
      const offset = document.getElementById('pubNavbar')?.offsetHeight || 70;
      window.scrollTo({
        top: target.offsetTop - offset,
        behavior: 'smooth'
      });
    });
  });

  /* ── Highlight nav actif au scroll ────────────────────────── */
  const sections  = document.querySelectorAll('section[id]');
  const navLinks  = document.querySelectorAll('.pub-navbar__link[href*="#"]');
  const navHeight = document.getElementById('pubNavbar')?.offsetHeight || 70;

  function highlightNav() {
    let current = '';
    sections.forEach(section => {
      if (window.scrollY >= section.offsetTop - navHeight - 40) {
        current = section.id;
      }
    });
    navLinks.forEach(link => {
      const href = link.getAttribute('href');
      link.classList.toggle('pub-navbar__link--active', href.includes(current) && current !== '');
    });
  }

  window.addEventListener('scroll', highlightNav, { passive: true });

});
