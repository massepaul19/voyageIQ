/**
 * analytique.js — Module analytique pour VoyageIQ
 * Gestion des graphiques, analyses et rapports
 */

class AnalytiqueManager {
  constructor() {
    this.charts = new Map();
    this.currentPeriod = 'month';
    this.init();
  }

  init() {
    console.log('[VoyageIQ] Module analytique initialisé.');
    this.setupEventListeners();
    this.loadInitialData();
    this.initializeCharts();
  }

  setupEventListeners() {
    // Sélecteurs de période
    const periodBtns = document.querySelectorAll('.period-btn');
    periodBtns.forEach(btn => {
      btn.addEventListener('click', (e) => {
        this.changePeriod(e.target.dataset.period);
      });
    });

    // Boutons d'export
    const exportBtns = document.querySelectorAll('.export-btn');
    exportBtns.forEach(btn => {
      btn.addEventListener('click', (e) => {
        this.exportData(e.target.dataset.format);
      });
    });

    // Filtres
    const filters = document.querySelectorAll('.analytique-filters select, .analytique-filters input');
    filters.forEach(filter => {
      filter.addEventListener('change', () => this.applyFilters());
    });
  }

  async loadInitialData() {
    try {
      this.showLoading();
      const response = await fetch('/api/analytics/data', {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        }
      });

      if (!response.ok) {
        throw new Error('Erreur lors du chargement des données');
      }

      const data = await response.json();
      this.updateKPIs(data.kpis);
      this.updateCharts(data.charts);
      this.updateTables(data.tables);
    } catch (error) {
      console.error('Erreur chargement données:', error);
      this.showError('Erreur lors du chargement des données');
    } finally {
      this.hideLoading();
    }
  }

  changePeriod(period) {
    this.currentPeriod = period;

    // Mise à jour des boutons
    document.querySelectorAll('.period-btn').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.period === period);
    });

    // Rechargement des données
    this.loadInitialData();
  }

  updateKPIs(kpis) {
    Object.entries(kpis).forEach(([key, value]) => {
      const element = document.querySelector(`[data-kpi="${key}"]`);
      if (element) {
        const valueEl = element.querySelector('.kpi-value');
        const changeEl = element.querySelector('.kpi-change');

        if (valueEl) valueEl.textContent = this.formatNumber(value.current);
        if (changeEl && value.change) {
          changeEl.textContent = `${value.change > 0 ? '+' : ''}${value.change}%`;
          changeEl.className = `kpi-change kpi-change--${value.change >= 0 ? 'positive' : 'negative'}`;
        }
      }
    });
  }

  initializeCharts() {
    // Graphique principal
    const mainChartCtx = document.getElementById('main-chart');
    if (mainChartCtx) {
      this.charts.set('main', new Chart(mainChartCtx, {
        type: 'line',
        data: {
          labels: [],
          datasets: [{
            label: 'Voyages',
            data: [],
            borderColor: 'var(--gold)',
            backgroundColor: 'rgba(201, 168, 76, 0.1)',
            tension: 0.4,
            fill: true
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              display: false
            }
          },
          scales: {
            y: {
              beginAtZero: true,
              grid: {
                color: 'rgba(255, 255, 255, 0.1)'
              },
              ticks: {
                color: 'var(--t3)'
              }
            },
            x: {
              grid: {
                color: 'rgba(255, 255, 255, 0.1)'
              },
              ticks: {
                color: 'var(--t3)'
              }
            }
          }
        }
      }));
    }

    // Graphiques secondaires
    const secondaryCharts = ['revenue-chart', 'performance-chart'];
    secondaryCharts.forEach(chartId => {
      const ctx = document.getElementById(chartId);
      if (ctx) {
        this.charts.set(chartId, new Chart(ctx, {
          type: 'doughnut',
          data: {
            labels: [],
            datasets: [{
              data: [],
              backgroundColor: [
                'var(--gold)',
                'var(--marine)',
                'var(--orange)',
                'var(--ok)',
                'var(--err)'
              ],
              borderWidth: 0
            }]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              legend: {
                position: 'bottom',
                labels: {
                  color: 'var(--t2)',
                  padding: 20,
                  usePointStyle: true
                }
              }
            }
          }
        }));
      }
    });
  }

  updateCharts(chartData) {
    Object.entries(chartData).forEach(([chartId, data]) => {
      const chart = this.charts.get(chartId);
      if (chart) {
        chart.data.labels = data.labels;
        chart.data.datasets[0].data = data.values;
        chart.update();
      }
    });
  }

  updateTables(tableData) {
    Object.entries(tableData).forEach(([tableId, data]) => {
      const tbody = document.querySelector(`#${tableId} tbody`);
      if (tbody) {
        tbody.innerHTML = data.rows.map(row => `
          <tr>
            ${row.cells.map(cell => `<td>${cell}</td>`).join('')}
          </tr>
        `).join('');
      }
    });
  }

  applyFilters() {
    const filters = this.getFilterValues();
    this.loadFilteredData(filters);
  }

  getFilterValues() {
    const filters = {};
    const filterElements = document.querySelectorAll('.analytique-filters select, .analytique-filters input');

    filterElements.forEach(element => {
      if (element.type === 'checkbox') {
        filters[element.name] = element.checked;
      } else {
        filters[element.name] = element.value;
      }
    });

    return filters;
  }

  async loadFilteredData(filters) {
    try {
      this.showLoading();
      const response = await fetch('/api/analytics/filtered', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ filters, period: this.currentPeriod })
      });

      if (!response.ok) {
        throw new Error('Erreur lors du filtrage');
      }

      const data = await response.json();
      this.updateKPIs(data.kpis);
      this.updateCharts(data.charts);
      this.updateTables(data.tables);
    } catch (error) {
      console.error('Erreur filtrage:', error);
      this.showError('Erreur lors de l\'application des filtres');
    } finally {
      this.hideLoading();
    }
  }

  async exportData(format) {
    try {
      const response = await fetch(`/api/analytics/export/${format}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          period: this.currentPeriod,
          filters: this.getFilterValues()
        })
      });

      if (!response.ok) {
        throw new Error('Erreur lors de l\'export');
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `analytics_${this.currentPeriod}_${Date.now()}.${format}`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      this.showSuccess('Export réussi');
    } catch (error) {
      console.error('Erreur export:', error);
      this.showError('Erreur lors de l\'export');
    }
  }

  formatNumber(num) {
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1) + 'M';
    } else if (num >= 1000) {
      return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
  }

  showLoading() {
    const loadingElements = document.querySelectorAll('.chart-loading');
    loadingElements.forEach(el => el.style.display = 'flex');
  }

  hideLoading() {
    const loadingElements = document.querySelectorAll('.chart-loading');
    loadingElements.forEach(el => el.style.display = 'none');
  }

  showError(message) {
    this.showNotification(message, 'error');
  }

  showSuccess(message) {
    this.showNotification(message, 'success');
  }

  showNotification(message, type) {
    // Créer une notification temporaire
    const notification = document.createElement('div');
    notification.className = `notification notification--${type}`;
    notification.textContent = message;
    notification.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: ${type === 'error' ? 'var(--err)' : 'var(--ok)'};
      color: white;
      padding: 12px 20px;
      border-radius: var(--radius);
      z-index: 3000;
      animation: slideInRight 0.3s ease;
    `;

    document.body.appendChild(notification);

    setTimeout(() => {
      notification.style.animation = 'slideOutRight 0.3s ease';
      setTimeout(() => {
        document.body.removeChild(notification);
      }, 300);
    }, 3000);
  }
}

// Initialisation
document.addEventListener('DOMContentLoaded', function() {
  if (document.querySelector('.analytique-page')) {
    new AnalytiqueManager();
  }
});
